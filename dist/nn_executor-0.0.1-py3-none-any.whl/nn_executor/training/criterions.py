
class BaseCriterion:
    def __init__(self):
        pass
    
    def __call__(self, y_pred, y_ref):
        pass
